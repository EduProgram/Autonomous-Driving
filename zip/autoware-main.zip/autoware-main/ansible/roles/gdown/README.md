# Role: gdown

This role installs gdown to download files from CMakeLists.txt.

## Inputs

None.

## Manual Installation

```bash
# Install gdown to download files from CMakeLists.txt
pip3 install gdown
```
