# geographiclib

## Inputs

None.

## Manual Installation

```bash
sudo apt install geographiclib-tools

# Add EGM2008 geoid grid to geographiclib
sudo geographiclib-get-geoids egm2008-1
```
